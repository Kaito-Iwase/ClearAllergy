"""Synthetic-only drill on containers created by this task, no remote DB access."""
import hashlib
import json
import pathlib
import subprocess
import time
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
OUT = ROOT / '.agent-runs' / 'utc-recovery-evidence-r2'
OUT.mkdir(exist_ok="--restore-only" in sys.argv)
SOURCE = 'ca-utc-boundaries-r2-20261025'
RESTORE = 'ca-utc-restore-20261025'
IMAGE = 'postgres@sha256:858bb5e98eed02eb8cafbcdc007f9a65d1b613972028944a8ec2133ccaf80d27'
MIGRATION = '20261024000000_utc_timestamp_contract'
TABLES = ['User', 'Shop', 'AdminInvite', 'AuditLog', 'MenuItem', 'Allergen', 'MenuItemAllergen',
          'MenuFoodReview', 'MenuPublicationConfirmation', 'MenuFoodIssueResolution']
RESULTS = []

def run(args, data=None, ok=True):
    p = subprocess.run(args, input=data, capture_output=True)
    if ok and p.returncode != 0:
        raise AssertionError('Command failed: ' + ' '.join(args[:3]))
    return p

def check_owner(container):
    config = json.loads(run(['docker', 'inspect', container]).stdout)[0]
    assert config['Config']['Labels']['clearallergy.task'] == 'utc-boundaries-20261025'
    assert config['Config']['Image'] == IMAGE or container == SOURCE

def psql(container, sql, ok=True):
    check_owner(container)
    return run(['docker', 'exec', '-i', container, 'psql', '-X', '-qAt', '-v', 'ON_ERROR_STOP=1',
                '-U', 'clearallergy_ci', '-d', 'clearallergy_ci'], sql.encode(), ok)

def query(container, sql):
    return json.loads(psql(container, sql).stdout)

def snapshot(container):
    return {table: query(container, f'''SELECT COALESCE(jsonb_agg(to_jsonb(t) ORDER BY to_jsonb(t)::text), '[]')
            FROM "{table}" t;''') for table in TABLES}

def catalog(container):
    statements = {
        'columns': '''SELECT table_name,column_name,ordinal_position,data_type,udt_name,is_nullable,
            column_default,character_maximum_length,numeric_precision,numeric_scale,datetime_precision
            FROM information_schema.columns WHERE table_schema='public' ORDER BY table_name,ordinal_position''',
        'functions': '''SELECT p.proname,pg_get_function_identity_arguments(p.oid) args,pg_get_functiondef(p.oid) definition
            FROM pg_proc p JOIN pg_namespace n ON n.oid=p.pronamespace
            WHERE n.nspname='public' ORDER BY p.proname,args''',
        'constraints': '''SELECT c.relname,con.conname,pg_get_constraintdef(con.oid) definition,
            con.condeferrable,con.condeferred,con.convalidated FROM pg_constraint con
            JOIN pg_class c ON c.oid=con.conrelid JOIN pg_namespace n ON n.oid=c.relnamespace
            WHERE n.nspname='public' ORDER BY c.relname,con.conname''',
        'indexes': '''SELECT tablename,indexname,indexdef FROM pg_indexes WHERE schemaname='public'
            ORDER BY tablename,indexname''',
        'triggers': '''SELECT c.relname,t.tgname,t.tgenabled,pg_get_triggerdef(t.oid) definition
            FROM pg_trigger t JOIN pg_class c ON c.oid=t.tgrelid JOIN pg_namespace n ON n.oid=c.relnamespace
            WHERE n.nspname='public' AND NOT t.tgisinternal ORDER BY c.relname,t.tgname''',
        'enums': '''SELECT t.typname,e.enumlabel,e.enumsortorder FROM pg_type t
            JOIN pg_enum e ON e.enumtypid=t.oid JOIN pg_namespace n ON n.oid=t.typnamespace
            WHERE n.nspname='public' ORDER BY t.typname,e.enumsortorder''',
    }
    return {name: query(container, f"SELECT COALESCE(jsonb_agg(to_jsonb(t)), '[]') FROM ({sql}) t;")
            for name, sql in statements.items()}

def passed(message):
    RESULTS.append(message)
    print('PASS: ' + message, flush=True)

def save(name, obj):
    (OUT / name).write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf8')

def dump(name):
    data = run(['docker', 'exec', SOURCE, 'pg_dump', '-Fc', '-U', 'clearallergy_ci', '-d', 'clearallergy_ci']).stdout
    (OUT / name).write_bytes(data)
    return data

if '--restore-only' in sys.argv:
    before_rows = json.loads((OUT/'before-rows.json').read_text(encoding='utf8'))
    before_catalog = json.loads((OUT/'before-catalog.json').read_text(encoding='utf8'))
    after_rows = json.loads((OUT/'after-rows.json').read_text(encoding='utf8'))
    after_catalog = json.loads((OUT/'after-catalog.json').read_text(encoding='utf8'))
    before_dump, after_dump = (OUT/'before.dump').read_bytes(), (OUT/'after.dump').read_bytes()
    sql = (ROOT/'prisma/migrations'/MIGRATION/'migration.sql').read_text(encoding='utf8')
    RESULTS.extend(['legacy writer provenance counterexample', 'late SQL failure atomic rollback',
        'tenth ALTER lock timeout atomic rollback', 'exact allowed catalog delta and row preservation', 'direct SQL replay'])
else:
    check_owner(SOURCE)
    assert query(SOURCE, "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';") == 0
    assert query(SOURCE, "SELECT to_jsonb(current_database() = 'clearallergy_ci' AND current_user = 'clearallergy_ci');")
    for migration in sorted((ROOT / 'prisma/migrations').iterdir()):
        if migration.is_dir() and migration.name < MIGRATION:
            psql(SOURCE, (migration / 'migration.sql').read_text(encoding='utf8'))
    
    fixture = '''BEGIN;
    SET LOCAL TIME ZONE 'Asia/Tokyo';
    INSERT INTO "User" ("id","email","updatedAt") VALUES ('legacy-default','legacy@example.invalid',TIMESTAMP '2026-01-01');
    INSERT INTO "User" ("id","email","createdAt","updatedAt") VALUES ('provided-utc','provided@example.invalid',CURRENT_TIMESTAMP AT TIME ZONE 'UTC',TIMESTAMP '2026-01-01');
    INSERT INTO "User" ("id","email","createdAt","updatedAt") SELECT 'same-value-other-source','same@example.invalid',"createdAt",TIMESTAMP '2026-01-01' FROM "User" WHERE "id"='legacy-default';
    INSERT INTO "Shop" ("id","name","userId","updatedAt") VALUES ('synthetic-shop','【架空】UTC復旧','provided-utc',TIMESTAMP '2026-01-01');
    INSERT INTO "AdminInvite" ("id","email","shopId","expiresAt","invitedByClerkUserId","updatedAt") VALUES ('synthetic-invite','invite@example.invalid','synthetic-shop',TIMESTAMP '2030-01-01','synthetic-actor',TIMESTAMP '2026-01-01');
    INSERT INTO "AuditLog" ("id","action","targetType","targetId","success") VALUES ('synthetic-audit','synthetic-fixture','shop','synthetic-shop',TRUE);
    INSERT INTO "Allergen" ("id","slug","nameJa","nameEn","updatedAt") VALUES ('synthetic-allergen','synthetic','架空','Synthetic',TIMESTAMP '2026-01-01');
    INSERT INTO "MenuItem" ("id","shopId","name","updatedAt") VALUES ('synthetic-menu','synthetic-shop','【架空】UTC復旧',TIMESTAMP '2026-01-01');
    INSERT INTO "MenuItemAllergen" ("menuItemId","allergenId","status","updatedAt") SELECT 'synthetic-menu',"id",'CONTAINS'::"AllergenStatus",TIMESTAMP '2026-01-01' FROM "Allergen";
    INSERT INTO "MenuFoodReview" ("id","menuItemId","foodVersion","contentSnapshot","evidenceRefs","scope","checkedAt","actorUserId","unresolvedIssues")
    SELECT 'synthetic-review',"id","foodVersion",'{}'::jsonb,'架空資料','架空範囲',TIMESTAMP '2026-01-01','synthetic-actor','架空未解決' FROM "MenuItem" WHERE "id"='synthetic-menu';
    INSERT INTO "MenuFoodIssueResolution" ("id","menuItemId","foodReviewId","foodVersion","issueSnapshot","actorUserId") SELECT 'synthetic-resolution',"id",'synthetic-review',"foodVersion",'DBで上書き','synthetic-actor' FROM "MenuItem" WHERE "id"='synthetic-menu';
    INSERT INTO "MenuPublicationConfirmation" ("id","menuItemId","foodVersion","actorUserId") SELECT 'synthetic-publication',"id","foodVersion",'synthetic-actor' FROM "MenuItem" WHERE "id"='synthetic-menu';
    UPDATE "MenuItem" SET "isPublished"=TRUE WHERE "id"='synthetic-menu';
    COMMIT;'''
    psql(SOURCE, fixture)
    offset = query(SOURCE, '''SELECT EXTRACT(EPOCH FROM (a."createdAt"-b."createdAt")) FROM "User" a,"User" b WHERE a."id"='legacy-default' AND b."id"='provided-utc';''')
    assert offset == 32400
    assert query(SOURCE, '''SELECT to_jsonb(a."createdAt"=b."createdAt") FROM "User" a,"User" b WHERE a."id"='legacy-default' AND b."id"='same-value-other-source';''')
    passed('legacy DB default differs from explicit UTC by 9h; equal stored timestamps do not encode writer provenance')
    before_rows, before_catalog = snapshot(SOURCE), catalog(SOURCE)
    assert all(before_rows.values())
    assert before_rows['MenuItem'][0]['isPublished']
    save('before-rows.json', before_rows)
    save('before-catalog.json', before_catalog)
    before_dump = dump('before.dump')
    sql = (ROOT / 'prisma/migrations' / MIGRATION / 'migration.sql').read_text(encoding='utf8')
    assert sql.count('COMMIT;') == 1 and sql.rstrip().endswith('COMMIT;')
    failed = psql(SOURCE, sql.replace('COMMIT;', 'SELECT 1 / 0;\nCOMMIT;'), ok=False)
    assert failed.returncode != 0 and b'division by zero' in failed.stderr
    assert snapshot(SOURCE) == before_rows and catalog(SOURCE) == before_catalog
    passed('division by zero after all 10 ALTERs and 8 function replacements rolls back rows and catalog exactly')
    
    # Contend on the tenth ALTER, after the preceding nine have executed.
    holder = subprocess.Popen(['docker','exec','-i',SOURCE,'psql','-X','-qAt','-v','ON_ERROR_STOP=1','-U','clearallergy_ci','-d','clearallergy_ci'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    holder.stdin.write(b'''BEGIN; LOCK TABLE "MenuFoodIssueResolution" IN ACCESS EXCLUSIVE MODE; SELECT pg_sleep(5); ROLLBACK;''')
    holder.stdin.close()
    for _ in range(30):
        if query(SOURCE, '''SELECT count(*) FROM pg_locks WHERE relation='"MenuFoodIssueResolution"'::regclass AND mode='AccessExclusiveLock' AND granted;''') == 1:
            break
        time.sleep(.1)
    else:
        raise AssertionError('Fixture lock not observed')
    failed = psql(SOURCE, sql.replace('BEGIN;', "BEGIN;\nSET LOCAL lock_timeout='250ms';", 1), ok=False)
    assert failed.returncode != 0 and b'lock timeout' in failed.stderr
    assert holder.wait(timeout=15) == 0
    assert snapshot(SOURCE) == before_rows and catalog(SOURCE) == before_catalog
    passed('lock timeout on tenth ALTER rolls back the preceding nine defaults and preserves all rows')
    psql(SOURCE, sql)
    after_rows, after_catalog = snapshot(SOURCE), catalog(SOURCE)
    assert after_rows == before_rows
    for key in ['constraints','indexes','triggers','enums']:
        assert before_catalog[key] == after_catalog[key], key
    changed_columns = 0
    for old, new in zip(before_catalog['columns'], after_catalog['columns'], strict=True):
        if old != new:
            changed_columns += 1
            assert old['column_default'] == 'CURRENT_TIMESTAMP'
            assert new['column_default'] == "(CURRENT_TIMESTAMP AT TIME ZONE 'UTC'::text)"
            assert dict(old, column_default=new['column_default']) == new
    assert changed_columns == 10
    changed_functions = 0
    for old, new in zip(before_catalog['functions'], after_catalog['functions'], strict=True):
        if old != new:
            changed_functions += 1
            # Keep pre-existing UTC checkedAt expressions untouched. Only the eight
            # changed functions' timestamp assignments and SELECT output may differ.
            expected = old['definition'].replace('"updatedAt" = CURRENT_TIMESTAMP', '"updatedAt" = (CURRENT_TIMESTAMP AT TIME ZONE \'UTC\')')
            expected = expected.replace('        CURRENT_TIMESTAMP\n    FROM "unpublishedMenus"', '        (CURRENT_TIMESTAMP AT TIME ZONE \'UTC\')\n    FROM "unpublishedMenus"')
            expected = expected.replace(':= clock_timestamp();', ":= clock_timestamp() AT TIME ZONE 'UTC';")
            assert dict(old, definition=expected) == new, old['proname']
    assert changed_functions == 8
    passed('successful migration preserves every row; catalog changes exactly 10 defaults and 8 timestamp expressions')
    psql(SOURCE, sql)
    assert snapshot(SOURCE) == after_rows and catalog(SOURCE) == after_catalog
    passed('direct SQL replay preserves rows and catalog (separate from Prisma deploy/history semantics)')
    save('after-rows.json', after_rows)
    save('after-catalog.json', after_catalog)
    after_dump = dump('after.dump')
# Restore each archive into a separately created empty cluster. Never clean or
# overwrite an existing database. Both clusters have no exposed host ports.
for phase, data, rows, definitions in [('before',before_dump,before_rows,before_catalog), ('after',after_dump,after_rows,after_catalog)]:
    name = RESTORE + '-' + phase
    if run(['docker','inspect',name],ok=False).returncode != 0:
        run(['docker','run','-d','--name',name,'--label','clearallergy.task=utc-boundaries-20261025',
         '-e','POSTGRES_USER=clearallergy_ci','-e','POSTGRES_PASSWORD=local_ci_only',
         '-e','POSTGRES_DB=clearallergy_ci',IMAGE,'-c','timezone=America/Los_Angeles'])
    for _ in range(60):
        if run(['docker','exec',name,'pg_isready','-h','127.0.0.1','-U','clearallergy_ci','-d','clearallergy_ci'],ok=False).returncode == 0:
            break
        time.sleep(.1)
    check_owner(name)
    assert query(name, "SELECT count(*) FROM information_schema.tables WHERE table_schema='public';") == 0
    run(['docker','exec','-i',name,'pg_restore','--exit-on-error','-U','clearallergy_ci','-d','clearallergy_ci'],data)
    assert snapshot(name) == rows and catalog(name) == definitions
    if phase == 'before':
        psql(name, sql)
        assert snapshot(name) == after_rows and catalog(name) == after_catalog
    passed(phase + ' custom-format backup restores rows/catalog exactly in a fresh LA cluster' + ('; migration reapplies successfully' if phase == 'before' else ''))
    run(['docker','stop',name])
save('result.json', {'source_head': run(['git','rev-parse','HEAD']).stdout.decode().strip(), 'checks': RESULTS,
    'postgres': query(SOURCE,'SELECT to_jsonb(version());'), 'image': IMAGE,
    'backup_sha256': {name:hashlib.sha256((OUT/name).read_bytes()).hexdigest() for name in ['before.dump','after.dump']},
    'unverified':['Prisma failed migration ledger/resolve/deploy (official engine download CONNECT 403)', 'production provenance/data/locks/backup/provider roles and ACL', 'crash or disconnect after commit']})
run(['docker','stop',SOURCE])
print('Evidence saved to ' + str(OUT), flush=True)
